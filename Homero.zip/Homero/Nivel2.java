import greenfoot.*;  // (Actor, World, Greenfoot, GreenfootImage)

public class Nivel2 extends World
{
    /**
     * Create the crab world (the beach). Our world has a size 
     * of 560x560 cells, where every cell is just 1 pixel.
     */
    public Nivel2() 
    {
        super(906, 501, 1);
    }
}
